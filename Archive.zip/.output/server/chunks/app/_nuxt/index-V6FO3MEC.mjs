import { _ as __nuxt_component_0 } from './client-only-uYF1VBpJ.mjs';
import { Vue3Marquee } from 'vue3-marquee';
import { defineComponent, withAsyncContext, unref, withCtx, createVNode, useSSRContext, resolveComponent, openBlock, createBlock, Fragment, renderList, createTextVNode, toDisplayString, mergeProps } from 'vue';
import { ssrRenderComponent, ssrRenderAttrs, ssrRenderList, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';
import { b as useAsyncData, d as __nuxt_component_2$1, e as _sfc_main$5, _ as _export_sfc } from '../server.mjs';
import { Swiper, SwiperSlide } from 'swiper/vue';
import { Autoplay } from 'swiper/modules';
import { u as useHead } from './index-tbNGurtz.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main$2 = {
  components: {
    Vue3Marquee
  },
  props: {
    data: {
      type: Array,
      required: true
    }
  }
};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Vue3Marquee = resolveComponent("Vue3Marquee");
  _push(`<div${ssrRenderAttrs(_attrs)}>`);
  _push(ssrRenderComponent(_component_Vue3Marquee, {
    class: "marquee_home",
    clone: true,
    duration: 20
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<!--[-->`);
        ssrRenderList($props.data, (value, key) => {
          _push2(`<div${_scopeId}><p${_scopeId}>${ssrInterpolate(value)}<span${_scopeId}>-</span></p></div>`);
        });
        _push2(`<!--]-->`);
      } else {
        return [
          (openBlock(true), createBlock(Fragment, null, renderList($props.data, (value, key) => {
            return openBlock(), createBlock("div", { key }, [
              createVNode("p", null, [
                createTextVNode(toDisplayString(value), 1),
                createVNode("span", null, "-")
              ])
            ]);
          }), 128))
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/home/AppMarquee.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main$1 = {
  data() {
    return {
      items: [],
      status: 0,
      perPage: 1,
      space: 0
    };
  },
  methods: {
    async portafolio() {
      const portfolioResponse = await fetch("https://admin.garnierbbdo.com/api/portafolio");
      this.status = portfolioResponse.status;
      await portfolioResponse.json().then((data) => {
        this.items = data.data.items.items.splice(0, 10);
      });
    },
    viewPerPage() {
      if ((void 0).innerWidth >= 1600) {
        this.perPage = 5;
        this.space = 30;
      } else if ((void 0).innerWidth >= 1100) {
        this.perPage = 4;
        this.space = 30;
      } else if ((void 0).innerWidth >= 901) {
        this.perPage = 3;
        this.space = 30;
      } else if ((void 0).innerWidth >= 550) {
        this.perPage = 2;
        this.space = 30;
      } else {
        this.perPage = 1;
        this.space = 0;
      }
    }
  },
  mounted() {
    this.viewPerPage();
  },
  created() {
    this.portafolio();
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Swiper = Swiper;
  const _component_SwiperSlide = SwiperSlide;
  const _component_NuxtLink = __nuxt_component_2$1;
  const _component_BootstrapIcon = _sfc_main$5;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "slider" }, _attrs))}>`);
  if ($data.status == 200) {
    _push(ssrRenderComponent(_component_Swiper, {
      onResize: $options.viewPerPage,
      modules: ["SwiperAutoplay" in _ctx ? _ctx.SwiperAutoplay : unref(Autoplay)],
      autoplay: {
        delay: 2e3,
        disableOnInteraction: true
      },
      spaceBetween: $data.space,
      slidesPerView: $data.perPage
    }, {
      default: withCtx((_, _push2, _parent2, _scopeId) => {
        if (_push2) {
          _push2(`<!--[-->`);
          ssrRenderList($data.items, (item, key) => {
            _push2(ssrRenderComponent(_component_SwiperSlide, {
              key,
              class: "trabajo_slider"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<section class="item"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_NuxtLink, {
                    title: item.name,
                    to: `/insaltable/${item.slug}`
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<img${ssrRenderAttr("src", item.image)}${ssrRenderAttr("alt", item.name)}${_scopeId3}><section${_scopeId3}><div${_scopeId3}><h2${ssrRenderAttr("title", item.name)}${_scopeId3}>${ssrInterpolate(item.name)}</h2><span${ssrRenderAttr("title", item.client)}${_scopeId3}>${ssrInterpolate(item.client)}</span></div><div class="next"${_scopeId3}><button title="Ingresar"${_scopeId3}>`);
                        _push4(ssrRenderComponent(_component_BootstrapIcon, { name: "arrow-right" }, null, _parent4, _scopeId3));
                        _push4(`</button></div></section>`);
                      } else {
                        return [
                          createVNode("img", {
                            src: item.image,
                            alt: item.name
                          }, null, 8, ["src", "alt"]),
                          createVNode("section", null, [
                            createVNode("div", null, [
                              createVNode("h2", {
                                title: item.name
                              }, toDisplayString(item.name), 9, ["title"]),
                              createVNode("span", {
                                title: item.client
                              }, toDisplayString(item.client), 9, ["title"])
                            ]),
                            createVNode("div", { class: "next" }, [
                              createVNode("button", { title: "Ingresar" }, [
                                createVNode(_component_BootstrapIcon, { name: "arrow-right" })
                              ])
                            ])
                          ])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(`</section>`);
                } else {
                  return [
                    createVNode("section", { class: "item" }, [
                      createVNode(_component_NuxtLink, {
                        title: item.name,
                        to: `/insaltable/${item.slug}`
                      }, {
                        default: withCtx(() => [
                          createVNode("img", {
                            src: item.image,
                            alt: item.name
                          }, null, 8, ["src", "alt"]),
                          createVNode("section", null, [
                            createVNode("div", null, [
                              createVNode("h2", {
                                title: item.name
                              }, toDisplayString(item.name), 9, ["title"]),
                              createVNode("span", {
                                title: item.client
                              }, toDisplayString(item.client), 9, ["title"])
                            ]),
                            createVNode("div", { class: "next" }, [
                              createVNode("button", { title: "Ingresar" }, [
                                createVNode(_component_BootstrapIcon, { name: "arrow-right" })
                              ])
                            ])
                          ])
                        ]),
                        _: 2
                      }, 1032, ["title", "to"])
                    ])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
          });
          _push2(`<!--]-->`);
        } else {
          return [
            (openBlock(true), createBlock(Fragment, null, renderList($data.items, (item, key) => {
              return openBlock(), createBlock(_component_SwiperSlide, {
                key,
                class: "trabajo_slider"
              }, {
                default: withCtx(() => [
                  createVNode("section", { class: "item" }, [
                    createVNode(_component_NuxtLink, {
                      title: item.name,
                      to: `/insaltable/${item.slug}`
                    }, {
                      default: withCtx(() => [
                        createVNode("img", {
                          src: item.image,
                          alt: item.name
                        }, null, 8, ["src", "alt"]),
                        createVNode("section", null, [
                          createVNode("div", null, [
                            createVNode("h2", {
                              title: item.name
                            }, toDisplayString(item.name), 9, ["title"]),
                            createVNode("span", {
                              title: item.client
                            }, toDisplayString(item.client), 9, ["title"])
                          ]),
                          createVNode("div", { class: "next" }, [
                            createVNode("button", { title: "Ingresar" }, [
                              createVNode(_component_BootstrapIcon, { name: "arrow-right" })
                            ])
                          ])
                        ])
                      ]),
                      _: 2
                    }, 1032, ["title", "to"])
                  ])
                ]),
                _: 2
              }, 1024);
            }), 128))
          ];
        }
      }),
      _: 1
    }, _parent));
  } else {
    _push(`<!---->`);
  }
  _push(`</div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/home/AppSlider.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useHead({
      title: "Agencia de publicidad - Garnier BBDO",
      meta: [
        {
          name: "description",
          content: "Somos agencia de publicidad costarricense, fundada por Alberto H. Garnier en 1921, y parte del BBDO Worldwide Network desde 1985. A Costa Rican Advertising Agency, founded by Alberto H. Garnier in 1921, and part of the BBDO Worldwide Network since 1985."
        },
        {
          name: "og:image",
          content: "/favicon.ico"
        },
        {
          name: "twitter:image",
          content: "/favicon.ico"
        },
        {
          name: "og:title",
          content: "Agencia de publicidad - Garnier BBDO"
        },
        {
          name: "twitter:title",
          content: "Agencia de publicidad - Garnier BBDO"
        },
        {
          name: "og:description",
          content: "Somos agencia de publicidad costarricense, fundada por Alberto H. Garnier en 1921, y parte del BBDO Worldwide Network desde 1985. A Costa Rican Advertising Agency, founded by Alberto H. Garnier in 1921, and part of the BBDO Worldwide Network since 1985."
        },
        {
          name: "twitter:description",
          content: "Somos agencia de publicidad costarricense, fundada por Alberto H. Garnier en 1921, y parte del BBDO Worldwide Network desde 1985. A Costa Rican Advertising Agency, founded by Alberto H. Garnier in 1921, and part of the BBDO Worldwide Network since 1985."
        }
      ]
    });
    const { data, error } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "item",
      () => $fetch(`/api/home`, {
        method: "GET",
        baseURL: "https://admin.garnierbbdo.com"
      })
    )), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_ClientOnly = __nuxt_component_0;
      const _component_HomeAppMarquee = __nuxt_component_1;
      const _component_HomeAppSlider = __nuxt_component_2;
      const _component_NuxtLink = __nuxt_component_2$1;
      const _component_BootstrapIcon = _sfc_main$5;
      _push(`<!--[--><h1 class="title_home">Agencia de publicidad - Garnier BBDO</h1><div>`);
      _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
      _push(`<header>`);
      _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
      _push(`<section id="marquee_item">`);
      _push(ssrRenderComponent(_component_HomeAppMarquee, {
        data: (_a = unref(data)) == null ? void 0 : _a.data.item.notices
      }, null, _parent));
      _push(`</section></header>`);
      _push(ssrRenderComponent(_component_HomeAppSlider, null, null, _parent));
      _push(`<section class="insaltable_link">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/insaltable",
        title: "Ver m\xE1s"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="text"${_scopeId}> Ver m\xE1s </span><span class="icon"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_BootstrapIcon, { name: "arrow-right" }, null, _parent2, _scopeId));
            _push2(`</span>`);
          } else {
            return [
              createVNode("span", { class: "text" }, " Ver m\xE1s "),
              createVNode("span", { class: "icon" }, [
                createVNode(_component_BootstrapIcon, { name: "arrow-right" })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</section></div><!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-V6FO3MEC.mjs.map
