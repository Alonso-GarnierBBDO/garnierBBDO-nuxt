import { b as useAsyncData, d as __nuxt_component_2, e as _sfc_main$5 } from '../server.mjs';
import { u as useHead } from './index-tbNGurtz.mjs';
import { defineComponent, withAsyncContext, mergeProps, unref, withCtx, openBlock, createBlock, createCommentVNode, createVNode, toDisplayString, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderList, ssrRenderComponent, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useHead({
      title: "Agencia del a\xF1o - Garnier BBDO",
      meta: [
        {
          name: "description",
          content: "Descubre la excelencia creativa con nuestro portafolio galardonado. Como agencia del a\xF1o, nos enorgullece presentar un repertorio excepcional de proyectos innovadores y exitosos. Desde estrategias de marca hasta campa\xF1as impactantes, explorar nuestro portafolio es sumergirse en un mundo de creatividad sin l\xEDmites. \xDAnete a nosotros en el viaje hacia soluciones visualmente impresionantes y resultados excepcionales. \xA1Descubre c\xF3mo podemos llevar tu visi\xF3n al siguiente nivel hoy mismo!"
        },
        {
          name: "og:image",
          content: "/favicon.ico"
        },
        {
          name: "twitter:image",
          content: "/favicon.ico"
        },
        {
          name: "og:title",
          content: "Agencia del a\xF1o - Garnier BBDO"
        },
        {
          name: "twitter:title",
          content: "Agencia del a\xF1o - Garnier BBDO"
        },
        {
          name: "og:description",
          content: "Descubre la excelencia creativa con nuestro portafolio galardonado. Como agencia del a\xF1o, nos enorgullece presentar un repertorio excepcional de proyectos innovadores y exitosos. Desde estrategias de marca hasta campa\xF1as impactantes, explorar nuestro portafolio es sumergirse en un mundo de creatividad sin l\xEDmites. \xDAnete a nosotros en el viaje hacia soluciones visualmente impresionantes y resultados excepcionales. \xA1Descubre c\xF3mo podemos llevar tu visi\xF3n al siguiente nivel hoy mismo!"
        },
        {
          name: "twitter:description",
          content: "Descubre la excelencia creativa con nuestro portafolio galardonado. Como agencia del a\xF1o, nos enorgullece presentar un repertorio excepcional de proyectos innovadores y exitosos. Desde estrategias de marca hasta campa\xF1as impactantes, explorar nuestro portafolio es sumergirse en un mundo de creatividad sin l\xEDmites. \xDAnete a nosotros en el viaje hacia soluciones visualmente impresionantes y resultados excepcionales. \xA1Descubre c\xF3mo podemos llevar tu visi\xF3n al siguiente nivel hoy mismo!"
        }
      ]
    });
    const { data } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "portafolio",
      () => $fetch(`/api/portafolio`, {
        method: "GET",
        baseURL: "https://admin.garnierbbdo.com"
      })
    )), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b;
      const _component_NuxtLink = __nuxt_component_2;
      const _component_BootstrapIcon = _sfc_main$5;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "page portafolio" }, _attrs))}><h1>Portafolio Garnier BBDO</h1>`);
      if ((_a = unref(data)) == null ? void 0 : _a.data.items) {
        _push(`<section class="all"><!--[-->`);
        ssrRenderList((_b = unref(data)) == null ? void 0 : _b.data.items.items, (item, key) => {
          _push(ssrRenderComponent(_component_NuxtLink, {
            key,
            style: { backgroundImage: `url(${item.image})` },
            to: `/insaltable/${item.slug}`,
            title: item.name
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                if (key == 0) {
                  _push2(`<video${ssrRenderAttr("poster", item.image)}${ssrRenderAttr("src", item.video)} muted autoplay loop${_scopeId}></video>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`<section class="content"${_scopeId}><div${_scopeId}><h2${ssrRenderAttr("title", item.name)}${_scopeId}>${ssrInterpolate(item.name)}</h2><span${ssrRenderAttr("title", item.client)}${_scopeId}>${ssrInterpolate(item.client)}</span></div><div class="next"${_scopeId}><button title="Ingresar"${_scopeId}>`);
                _push2(ssrRenderComponent(_component_BootstrapIcon, { name: "arrow-right" }, null, _parent2, _scopeId));
                _push2(`</button></div></section>`);
              } else {
                return [
                  key == 0 ? (openBlock(), createBlock("video", {
                    key: 0,
                    poster: item.image,
                    src: item.video,
                    muted: "",
                    autoplay: "",
                    loop: ""
                  }, null, 8, ["poster", "src"])) : createCommentVNode("", true),
                  createVNode("section", { class: "content" }, [
                    createVNode("div", null, [
                      createVNode("h2", {
                        title: item.name
                      }, toDisplayString(item.name), 9, ["title"]),
                      createVNode("span", {
                        title: item.client
                      }, toDisplayString(item.client), 9, ["title"])
                    ]),
                    createVNode("div", { class: "next" }, [
                      createVNode("button", { title: "Ingresar" }, [
                        createVNode(_component_BootstrapIcon, { name: "arrow-right" })
                      ])
                    ])
                  ])
                ];
              }
            }),
            _: 2
          }, _parent));
        });
        _push(`<!--]--></section>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/insaltable/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-ms_W7g5-.mjs.map
