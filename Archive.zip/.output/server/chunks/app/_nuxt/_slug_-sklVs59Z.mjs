import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { f as useRoute, b as useAsyncData, s as showError, c as createError, _ as _export_sfc, e as _sfc_main$5 } from '../server.mjs';
import { defineComponent, withAsyncContext, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderAttr, ssrIncludeBooleanAttr } from 'vue/server-renderer';
import { u as useHead } from './index-tbNGurtz.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main$1 = {
  props: {
    title: String
  },
  data() {
    return {
      send: true,
      form: {
        file: null,
        name: null,
        lastName: null,
        email: null,
        linkedin: null,
        portafolio: null
      },
      error: "",
      button: "Envi\xE1 tu aplicaci\xF3n",
      disabledElement: false,
      openModal: false
    };
  },
  methods: {
    showModal() {
      this.openModal = false;
      (void 0).body.style.overflow = "auto";
    },
    alingMenu() {
      const labelsParagraph = (void 0).querySelectorAll("label p");
      labelsParagraph.forEach((e) => {
        const heightParagrah = e.offsetHeight;
        const labelElement = e.parentElement;
        const parentLabelElement = labelElement.parentElement;
        const inputElement = labelElement.querySelector("input");
        if (inputElement) {
          const heightInput = inputElement.offsetHeight;
          const topParagraph = heightParagrah / 2 + heightInput / 2 - 8;
          e.style.top = `${(topParagraph - 6) / 2}px`;
          inputElement.onfocus = () => {
            e.style.top = `${0 - heightParagrah + 5}px`;
            labelElement.style.marginTop = "30px";
            e.classList.add("focus");
          };
          inputElement.onblur = () => {
            if (inputElement.value.length == 0) {
              e.style.top = `${(topParagraph - 6) / 2}px`;
              labelElement.style.marginTop = "0px";
              e.classList.remove("focus");
            }
          };
          inputElement.oninput = () => {
            this.validateInput(inputElement, parentLabelElement);
          };
        }
      });
    },
    isValidEmail(value) {
      const reg = /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
      if (value.match(reg))
        return true;
      return false;
    },
    isValidURL(value) {
      const url_reg = new RegExp("^(http[s]?:\\/\\/(www\\.)?|ftp:\\/\\/(www\\.)?|www\\.){1}([0-9A-Za-z-\\.@:%_+~#=]+)+((\\.[a-zA-Z]{2,3})+)(/(.)*)?(\\?(.)*)?");
      var without_regex = new RegExp("^([0-9A-Za-z-\\.@:%_+~#=]+)+((\\.[a-zA-Z]{2,3})+)(/(.)*)?(\\?(.)*)?");
      if (url_reg.test(value) || without_regex.test(value)) {
        return true;
      }
      return false;
    },
    validateInput(inputElement, parentLabelElement) {
      const value = inputElement.value;
      const elementError = parentLabelElement.querySelector(".error");
      if (inputElement.required) {
        if (inputElement.getAttribute("type") == "email") {
          if (value.length) {
            if (this.isValidEmail(value)) {
              elementError.innerHTML = "";
            } else {
              elementError.innerHTML = "Correo electr\xF3nico invalido";
            }
          } else {
            elementError.innerHTML = inputElement.validationMessage;
          }
        } else {
          elementError.innerHTML = inputElement.validationMessage;
        }
      } else {
        if (inputElement.getAttribute("type") == "url") {
          if (value.length) {
            if (!this.isValidURL(value)) {
              elementError.innerHTML = "URL no valida";
            } else {
              elementError.innerHTML = "";
            }
          } else {
            elementError.innerHTML = "";
          }
        }
      }
    },
    sendCV(e) {
      var _a;
      e.preventDefault();
      this.send = true;
      const container = (void 0).querySelector(".cvContainer");
      const inputFile = container.querySelector("input");
      const errorFile = container.querySelector(".error");
      if (!(inputFile == null ? void 0 : inputFile.value.length)) {
        this.send = false;
        errorFile.innerHTML = "El CV es requerido";
        this.error = "Algunos items estan incorrectos";
      } else {
        if (((_a = this.form.name) == null ? void 0 : _a.length) && this.form.lastName && this.form.email && this.form.file) {
          this.sendForm();
          this.error = "";
        } else {
          this.error = "Algunos items estan incorrectos";
        }
      }
    },
    async sendForm() {
      var _a, _b;
      if (((_b = (_a = this.form.file) == null ? void 0 : _a.files) == null ? void 0 : _b.length) && this.form.name && this.form.lastName && this.form.email) {
        const selectedFile = this.form.file.files[0];
        const fileExtension = selectedFile.name.split(".").pop();
        const uniqueFileName = this.generateUniqueName() + "." + fileExtension;
        const updatedFile = new File([selectedFile], uniqueFileName, {
          type: selectedFile.type
        });
        const formData = new FormData();
        formData.append("name", this.form.name);
        formData.append("last_name", this.form.lastName);
        formData.append("email", this.form.email);
        if (this.form.linkedin) {
          formData.append("linkedin", this.form.linkedin);
        }
        if (this.form.portafolio) {
          formData.append("portafolio", this.form.portafolio);
        }
        if (this.title) {
          formData.append("puesto", this.title);
        } else {
          formData.append("puesto", "");
        }
        formData.append("cv", updatedFile);
        const inputs = (void 0).querySelectorAll("form input");
        inputs.forEach((e) => {
          e.disabled = true;
        });
        this.disabledElement = true;
        this.button = "Enviando aplicaci\xF3n";
        try {
          await fetch("https://admin.garnierbbdo.com/api/nuevo-empleo", {
            method: "POST",
            body: formData
          }).then((response) => {
            this.loadChange(inputs, response.status);
          }).catch((err) => {
            this.loadChange(inputs, 417);
          });
        } catch (err) {
          this.loadChange(inputs, 417);
        }
      } else {
        this.error = "Algunos items estan incorrectos";
      }
    },
    loadChange(inputs, response) {
      inputs.forEach((e) => {
        e.disabled = false;
      });
      this.disabledElement = false;
      this.button = "Envi\xE1 tu aplicaci\xF3n";
      if (response == 200) {
        const inputNameFile = (void 0).querySelector(".nameFile");
        inputNameFile.innerHTML = "";
        this.error = "";
        this.openModal = true;
        (void 0).body.style.overflow = "hidden";
        inputs.forEach((e) => {
          const parentElement = e.parentElement;
          const childElement = parentElement.querySelector("p");
          parentElement.style.marginTop = "0px";
          if (childElement) {
            childElement.classList.remove("focus");
          }
          e.value = "";
        });
        this.form.name = "";
        this.form.lastName = "";
        this.form.email = "";
        this.form.linkedin = "";
        this.form.portafolio = "";
        this.alingMenu();
      } else {
        this.error = "Parece que el servidor no est\xE1 respondiendo a su solicitud en este momento. Nuestro equipo ya est\xE1 trabajando para resolver este problema. Le pedimos disculpas por las molestias y le recomendamos que lo intente nuevamente m\xE1s tarde.";
        this.openModal = false;
      }
    },
    changeFIle(e) {
      var _a;
      const input = e.target;
      const parentElement = input.parentElement;
      const inputNameFile = parentElement == null ? void 0 : parentElement.querySelector(".nameFile");
      const errorFile = parentElement == null ? void 0 : parentElement.querySelector(".error");
      if ((_a = input.files) == null ? void 0 : _a.length) {
        const file = input.files[0];
        const nameFile = file.name;
        let reader = new FileReader();
        reader.addEventListener("load", () => {
          if ((file.type == "application/pdf" || file.type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document" || file.type == "application/msword" || file.type == "text/plain" || file.type == "text/rtf") && file.size <= 1236724) {
            inputNameFile.innerHTML = nameFile;
            errorFile.innerHTML = "";
            this.form.file = input;
            this.error = "";
          } else if (file.size > 1236724) {
            inputNameFile.innerHTML = "";
            errorFile.innerHTML = "El archivo no puede pesar m\xE1s de 1MB";
            this.form.file = null;
          } else {
            inputNameFile.innerHTML = "";
            errorFile.innerHTML = "Este archivo no es permitido";
            this.form.file = null;
          }
        }, false);
        if (file) {
          reader.readAsDataURL(file);
        }
      }
    },
    generateUUID() {
      return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
        /[xy]/g,
        function(c) {
          const r = Math.random() * 16 | 0, v = c === "x" ? r : r & 3 | 8;
          return v.toString(16);
        }
      );
    },
    // Con esta funcion generamos el nombre aleatorio del file
    generateUniqueName() {
      const timestamp = (/* @__PURE__ */ new Date()).getTime();
      const randomId = Math.floor(Math.random() * 1e4);
      const uuid = this.generateUUID();
      const shortenedUuid = uuid.substring(0, 8);
      return `file_${timestamp}_${randomId}_${shortenedUuid}`;
    }
  },
  mounted() {
    this.alingMenu();
  }
};
const _imports_0 = "" + buildAssetsURL("volcan_logo.iqfWTAW2.svg");
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_BootstrapIcon = _sfc_main$5;
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "formulario" }, _attrs))}><h4>Aplic\xE1 aqu\xED :)</h4><form action=""><section><label for="name"><p>Nombre</p><input${ssrRenderAttr("value", $data.form.name)} type="text" id="name" required></label><span class="error"></span></section><section><label for="last_name"><p>Apellidos</p><input${ssrRenderAttr("value", $data.form.lastName)} type="text" id="last_name" required></label><span class="error"></span></section><section><label for="email"><p>Correo electr\xF3nico</p><input${ssrRenderAttr("value", $data.form.email)} type="email" id="email" required></label><span class="error"></span></section><section><label for="linkedin"><p>Linkedin (Opcional)</p><input${ssrRenderAttr("value", $data.form.linkedin)} type="url" id="linkedin"></label><span class="error"></span></section><section><label for="portafolio_folder"><p>Portafolio o carpeta (Opcional)</p><input${ssrRenderAttr("value", $data.form.portafolio)} type="url" id="portafolio_folder"></label><span class="error"></span></section><label class="cvContainer" for="cv"><section><h4>cv / portafolio</h4><strong>compatibles: pdf, doc, docx, txt and rtf</strong><span class="nameFile"></span><span class="error"></span></section>`);
  _push(ssrRenderComponent(_component_BootstrapIcon, {
    class: "close",
    name: "paperclip"
  }, null, _parent));
  _push(`<input type="file" id="cv" accept="application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword, text/plain, text/rtf"></label><button type="submit" class="send"${ssrIncludeBooleanAttr($data.disabledElement) ? " disabled" : ""}>${ssrInterpolate($data.button)} `);
  _push(ssrRenderComponent(_component_BootstrapIcon, {
    class: "arrow",
    name: "arrow-right"
  }, null, _parent));
  _push(`<span class="loader"></span></button><span class="allError">${ssrInterpolate($data.error)}</span></form>`);
  if ($data.openModal) {
    _push(`<section class="modal"><section class="content"><img${ssrRenderAttr("src", _imports_0)} class="logo_volcan" alt="Logo del premio volcan"><button class="close">`);
    _push(ssrRenderComponent(_component_BootstrapIcon, {
      class: "arrow",
      name: "x-lg"
    }, null, _parent));
    _push(`</button><section><h2>\xA1Felicidades, su solicitud se envi\xF3 con \xE9xito!</h2><p>Si su perfil coincide con la vacante pronto nos pondremos con contacto.</p><button>Aceptar y cerrar</button></section></section></section>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</section>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/trabajo/AppFormulario.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a, _b, _c, _d, _e, _f, _g;
    let __temp, __restore;
    const route = useRoute();
    const param = route.params.slug;
    const { data } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "oportunidad",
      () => $fetch(`/api/empleos/${param}`, {
        method: "GET",
        baseURL: "https://admin.garnierbbdo.com"
      })
    )), __temp = await __temp, __restore(), __temp);
    if (!data.value) {
      showError(
        createError({
          statusCode: 404,
          statusMessage: "Not Found"
        })
      );
    }
    useHead({
      title: `${(_a = data.value) == null ? void 0 : _a.data.items.name} - Garnier BBDO`,
      meta: [
        {
          name: "description",
          content: `\xDAnete a nuestro equipo din\xE1mico como ${(_b = data.value) == null ? void 0 : _b.data.items.name} y haz avanzar tu carrera en un entorno colaborativo. Estamos buscando un profesional, con habilidades excepcionales para la comunicaci\xF3n y la resoluci\xF3n de problemas.`
        },
        {
          name: "og:image",
          content: "/favicon.ico"
        },
        {
          name: "twitter:image",
          content: "/favicon.ico"
        },
        {
          name: "og:title",
          content: `${(_c = data.value) == null ? void 0 : _c.data.items.name} - Garnier BBDO`
        },
        {
          name: "twitter:title",
          content: `${(_d = data.value) == null ? void 0 : _d.data.items.name} - Garnier BBDO`
        },
        {
          name: "og:description",
          content: `\xDAnete a nuestro equipo din\xE1mico como ${(_e = data.value) == null ? void 0 : _e.data.items.name} y haz avanzar tu carrera en un entorno colaborativo. Estamos buscando un profesional, con habilidades excepcionales para la comunicaci\xF3n y la resoluci\xF3n de problemas.`
        },
        {
          name: "twitter:description",
          content: `\xDAnete a nuestro equipo din\xE1mico como ${(_f = data.value) == null ? void 0 : _f.data.items.name} y haz avanzar tu carrera en un entorno colaborativo. Estamos buscando un profesional, con habilidades excepcionales para la comunicaci\xF3n y la resoluci\xF3n de problemas.`
        }
      ]
    });
    const dataPuesto = (_g = data.value) == null ? void 0 : _g.data.items;
    return (_ctx, _push, _parent, _attrs) => {
      var _a2, _b2, _c2, _d2, _e2, _f2, _g2;
      const _component_TrabajoAppFormulario = __nuxt_component_0;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "page oportunidad_laboral" }, _attrs))}><section class="content"><section class="header"><section class="subtitle"><h2>${ssrInterpolate((_a2 = unref(dataPuesto)) == null ? void 0 : _a2.subtitle)}</h2><span>${ssrInterpolate((_b2 = unref(dataPuesto)) == null ? void 0 : _b2.jornada)}</span></section><section class="title"><h1>${ssrInterpolate((_c2 = unref(dataPuesto)) == null ? void 0 : _c2.name)}</h1></section></section><section class="group"><h3>Responsabilidades</h3><section class="info">${(_d2 = unref(dataPuesto)) == null ? void 0 : _d2.responsabilidades}</section></section><section class="group"><h3>Especificaciones</h3><section class="info">${(_e2 = unref(dataPuesto)) == null ? void 0 : _e2.tareas}</section></section><section class="group"><h3>Requisitos</h3><section class="info">${(_f2 = unref(dataPuesto)) == null ? void 0 : _f2.requisitos}</section></section></section>`);
      _push(ssrRenderComponent(_component_TrabajoAppFormulario, {
        title: (_g2 = unref(dataPuesto)) == null ? void 0 : _g2.name
      }, null, _parent));
      _push(`</section>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/oportunidades/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-sklVs59Z.mjs.map
