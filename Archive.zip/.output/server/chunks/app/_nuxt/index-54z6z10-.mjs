import { Swiper, SwiperSlide } from 'swiper/vue';
import { b as useAsyncData, _ as _export_sfc, d as __nuxt_component_2, e as _sfc_main$5 } from '../server.mjs';
import { Grid, Pagination } from 'swiper/modules';
import { defineComponent, withAsyncContext, mergeProps, unref, useSSRContext, withCtx, createVNode, toDisplayString, createTextVNode, openBlock, createBlock, Fragment, renderList } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import { u as useHead } from './index-tbNGurtz.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main$1 = {
  name: "Slider Oportunidades",
  props: {
    data: {
      type: Object,
      required: false
    }
  },
  data() {
    return {
      columns: 1,
      space: 0,
      touch: false,
      grid: 10,
      clickable: true,
      jsonData: []
    };
  },
  methods: {
    setValues() {
      if (this.data) {
        this.jsonData = this.data;
        this.screen();
        (void 0).onresize = () => {
          this.screen();
        };
      }
    },
    screen() {
      if ((void 0).innerWidth >= 1600) {
        this.columns = 3;
        this.space = 30;
        this.grid = 3;
        this.touch = true;
      } else if ((void 0).innerWidth >= 1100) {
        this.columns = 2;
        this.space = 30;
        this.grid = 3;
        this.touch = true;
      } else if ((void 0).innerWidth >= 550) {
        this.columns = 2;
        this.space = 30;
        this.grid = 4;
        this.touch = true;
        this.clickable = false;
      } else {
        this.columns = 1;
        this.clickable = false;
      }
    },
    getAllWorks() {
    }
  },
  mounted() {
    this.setValues();
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Swiper = Swiper;
  const _component_SwiperSlide = SwiperSlide;
  const _component_NuxtLink = __nuxt_component_2;
  const _component_BootstrapIcon = _sfc_main$5;
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "works" }, _attrs))}>`);
  _push(ssrRenderComponent(_component_Swiper, {
    modules: ["SwiperGrid" in _ctx ? _ctx.SwiperGrid : unref(Grid), "SwiperPagination" in _ctx ? _ctx.SwiperPagination : unref(Pagination)],
    spaceBetween: 15,
    slidesPerView: $data.columns,
    grid: {
      rows: $data.grid
    },
    pagination: {
      clickable: $data.clickable
    },
    class: "mySwiper"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<!--[-->`);
        ssrRenderList($data.jsonData, (item) => {
          _push2(ssrRenderComponent(_component_SwiperSlide, { class: "item_slider" }, {
            default: withCtx((_2, _push3, _parent3, _scopeId2) => {
              if (_push3) {
                _push3(ssrRenderComponent(_component_NuxtLink, {
                  class: "item",
                  to: `oportunidades/${item.slug}`
                }, {
                  default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                    if (_push4) {
                      _push4(`<h2${_scopeId3}>${ssrInterpolate(item.name)}</h2><span${_scopeId3}>${ssrInterpolate(item.subtitle)}</span><div${_scopeId3}><span${_scopeId3}>${ssrInterpolate(item.lugar)} - <strong${_scopeId3}>${ssrInterpolate(item.jornada)}</strong></span><button${_scopeId3}>`);
                      _push4(ssrRenderComponent(_component_BootstrapIcon, { name: "arrow-right" }, null, _parent4, _scopeId3));
                      _push4(`</button></div>`);
                    } else {
                      return [
                        createVNode("h2", null, toDisplayString(item.name), 1),
                        createVNode("span", null, toDisplayString(item.subtitle), 1),
                        createVNode("div", null, [
                          createVNode("span", null, [
                            createTextVNode(toDisplayString(item.lugar) + " - ", 1),
                            createVNode("strong", null, toDisplayString(item.jornada), 1)
                          ]),
                          createVNode("button", null, [
                            createVNode(_component_BootstrapIcon, { name: "arrow-right" })
                          ])
                        ])
                      ];
                    }
                  }),
                  _: 2
                }, _parent3, _scopeId2));
              } else {
                return [
                  createVNode(_component_NuxtLink, {
                    class: "item",
                    to: `oportunidades/${item.slug}`
                  }, {
                    default: withCtx(() => [
                      createVNode("h2", null, toDisplayString(item.name), 1),
                      createVNode("span", null, toDisplayString(item.subtitle), 1),
                      createVNode("div", null, [
                        createVNode("span", null, [
                          createTextVNode(toDisplayString(item.lugar) + " - ", 1),
                          createVNode("strong", null, toDisplayString(item.jornada), 1)
                        ]),
                        createVNode("button", null, [
                          createVNode(_component_BootstrapIcon, { name: "arrow-right" })
                        ])
                      ])
                    ]),
                    _: 2
                  }, 1032, ["to"])
                ];
              }
            }),
            _: 2
          }, _parent2, _scopeId));
        });
        _push2(`<!--]-->`);
      } else {
        return [
          (openBlock(true), createBlock(Fragment, null, renderList($data.jsonData, (item) => {
            return openBlock(), createBlock(_component_SwiperSlide, { class: "item_slider" }, {
              default: withCtx(() => [
                createVNode(_component_NuxtLink, {
                  class: "item",
                  to: `oportunidades/${item.slug}`
                }, {
                  default: withCtx(() => [
                    createVNode("h2", null, toDisplayString(item.name), 1),
                    createVNode("span", null, toDisplayString(item.subtitle), 1),
                    createVNode("div", null, [
                      createVNode("span", null, [
                        createTextVNode(toDisplayString(item.lugar) + " - ", 1),
                        createVNode("strong", null, toDisplayString(item.jornada), 1)
                      ]),
                      createVNode("button", null, [
                        createVNode(_component_BootstrapIcon, { name: "arrow-right" })
                      ])
                    ])
                  ]),
                  _: 2
                }, 1032, ["to"])
              ]),
              _: 2
            }, 1024);
          }), 256))
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</section>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/trabajo/AppTrabajoSlider.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a;
    let __temp, __restore;
    useHead({
      title: "Oportunidades laborales - Garnier BBDO",
      meta: [
        {
          name: "description",
          content: "\xA1\xDAnete a nuestro equipo! Estamos en busca de talento apasionado y comprometido. Si eres una persona motivada, con habilidades excepcionales y deseas formar parte de nuestro crecimiento, \xA1env\xEDanos tu CV ahora! Descubre oportunidades emocionantes y contribuye a un ambiente de trabajo din\xE1mico."
        },
        {
          name: "og:image",
          content: "/favicon.ico"
        },
        {
          name: "twitter:image",
          content: "/favicon.ico"
        },
        {
          name: "og:title",
          content: "Oportunidades laborales - Garnier BBDO"
        },
        {
          name: "twitter:title",
          content: "Oportunidades laborales - Garnier BBDO"
        },
        {
          name: "og:description",
          content: "\xA1\xDAnete a nuestro equipo! Estamos en busca de talento apasionado y comprometido. Si eres una persona motivada, con habilidades excepcionales y deseas formar parte de nuestro crecimiento, \xA1env\xEDanos tu CV ahora! Descubre oportunidades emocionantes y contribuye a un ambiente de trabajo din\xE1mico."
        },
        {
          name: "twitter:description",
          content: "\xA1\xDAnete a nuestro equipo! Estamos en busca de talento apasionado y comprometido. Si eres una persona motivada, con habilidades excepcionales y deseas formar parte de nuestro crecimiento, \xA1env\xEDanos tu CV ahora! Descubre oportunidades emocionantes y contribuye a un ambiente de trabajo din\xE1mico."
        }
      ]
    });
    const { data } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "oportunidades",
      () => $fetch(`/api/empleos`, {
        method: "GET",
        baseURL: "https://admin.garnierbbdo.com"
      })
    )), __temp = await __temp, __restore(), __temp);
    let oportunidadesData = (_a = data.value) == null ? void 0 : _a.data.items;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_TrabajoAppTrabajoSlider = __nuxt_component_0;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "page" }, _attrs))}><section class="oportunidades"><section><h1>Crec\xE9 aqu\xED</h1><p class="font-linght"> En <strong class=""> Garnier BBDO</strong> creemos que la diversidad nos hace mejores en nuestro trabajo: Un ambiente inclusivo y con variados puntos de vista es el mejor catalizador de creatividad. </p><p class="font-linght"><strong class="">Queremos personas </strong> con diferentes formas de ver el mundo, capacidades, identidades, formaciones y nacionalidades. Aplic\xE1 para trabajar aqu\xED, no importa donde est\xE9s, <strong class=""> queremos crecer con vos.</strong></p></section>`);
      _push(ssrRenderComponent(_component_TrabajoAppTrabajoSlider, { data: unref(oportunidadesData) }, null, _parent));
      _push(`</section></section>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/oportunidades/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-54z6z10-.mjs.map
