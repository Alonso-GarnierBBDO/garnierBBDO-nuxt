import { _ as __nuxt_component_0 } from './client-only-uYF1VBpJ.mjs';
import { f as useRoute, b as useAsyncData, s as showError, c as createError, e as _sfc_main$5 } from '../server.mjs';
import { u as useHead } from './index-tbNGurtz.mjs';
import { defineComponent, withAsyncContext, unref, mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderList } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
    let __temp, __restore;
    const route = useRoute();
    const param = route.params.slug;
    const { data, status } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "portafolio",
      () => $fetch(`/api/portafolio/${param}`, {
        method: "GET",
        baseURL: "https://admin.garnierbbdo.com"
      })
    )), __temp = await __temp, __restore(), __temp);
    if (!data.value) {
      showError(
        createError({
          statusCode: 404,
          statusMessage: "Not Found"
        })
      );
    }
    useHead({
      title: `${(_a = data.value) == null ? void 0 : _a.data.item.titulo} - Garnier BBDO`,
      meta: [
        {
          name: "description",
          content: (_b = data.value) == null ? void 0 : _b.data.item.description
        },
        {
          name: "og:image",
          content: ((_c = data.value) == null ? void 0 : _c.data.item.images[0]) ? (_d = data.value) == null ? void 0 : _d.data.item.images[0] : "/favicon.ico"
        },
        {
          name: "twitter:image",
          content: ((_e = data.value) == null ? void 0 : _e.data.item.images[0]) ? (_f = data.value) == null ? void 0 : _f.data.item.images[0] : "/favicon.ico"
        },
        {
          name: "og:title",
          content: `${(_g = data.value) == null ? void 0 : _g.data.item.titulo} - Garnier BBDO`
        },
        {
          name: "twitter:title",
          content: `${(_h = data.value) == null ? void 0 : _h.data.item.titulo} - Garnier BBDO`
        },
        {
          name: "og:description",
          content: ((_i = data.value) == null ? void 0 : _i.data.item.description) ? (_j = data.value) == null ? void 0 : _j.data.item.description : "Somos agencia de publicidad costarricense, fundada por Alberto H. Garnier en 1921, y parte del BBDO Worldwide Network desde 1985. A Costa Rican Advertising Agency, founded by Alberto H. Garnier in 1921, and part of the BBDO Worldwide Network since 1985."
        },
        {
          name: "twitter:description",
          content: ((_k = data.value) == null ? void 0 : _k.data.item.description) ? (_l = data.value) == null ? void 0 : _l.data.item.description : "Somos agencia de publicidad costarricense, fundada por Alberto H. Garnier en 1921, y parte del BBDO Worldwide Network desde 1985. A Costa Rican Advertising Agency, founded by Alberto H. Garnier in 1921, and part of the BBDO Worldwide Network since 1985."
        }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a2, _b2, _c2, _d2, _e2, _f2;
      const _component_ClientOnly = __nuxt_component_0;
      const _component_BootstrapIcon = _sfc_main$5;
      if ((_a2 = unref(data)) == null ? void 0 : _a2.data.item) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "portafolio-individual" }, _attrs))}>`);
        _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
        _push(`<section class="page content" id="content"><section><div class="header"><section class="title"><h1${ssrRenderAttr("title", (_b2 = unref(data)) == null ? void 0 : _b2.data.item.titulo)}>${ssrInterpolate((_c2 = unref(data)) == null ? void 0 : _c2.data.item.titulo)}</h1><a title="Ver m\xE1s" href="#content">`);
        _push(ssrRenderComponent(_component_BootstrapIcon, { name: "arrow-down" }, null, _parent));
        _push(`</a></section><section class="description"><p>${ssrInterpolate((_d2 = unref(data)) == null ? void 0 : _d2.data.item.description)}</p></section></div><section class="contenido">${(_e2 = unref(data)) == null ? void 0 : _e2.data.item.content}</section><section class="images"><!--[-->`);
        ssrRenderList((_f2 = unref(data)) == null ? void 0 : _f2.data.item.images, (item, key) => {
          _push(`<section class="img"><img${ssrRenderAttr("src", item)}${ssrRenderAttr("alt", item)}></section>`);
        });
        _push(`<!--]--></section></section></section></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/insaltable/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-WE8HNrcc.mjs.map
