import { u as useHead } from './index-tbNGurtz.mjs';
import { b as useAsyncData } from '../server.mjs';
import { defineComponent, withAsyncContext, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import '@unhead/shared';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import 'vue-router';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useHead({
      title: "Nuestra historia - Garnier BBDO",
      meta: [
        {
          name: "description",
          content: "Descubre la inspiradora historia detr\xE1s de Garnier. Desde nuestros humildes comienzos hasta convertirnos en l\xEDderes de la industria, hemos construido nuestro camino con pasi\xF3n, innovaci\xF3n y dedicaci\xF3n. Explora c\xF3mo hemos superado desaf\xEDos, hemos alcanzado \xE9xitos significativos y hemos forjado relaciones s\xF3lidas. \xDAnete a nosotros en este viaje, donde cada cap\xEDtulo cuenta una historia de crecimiento, creatividad y compromiso con la excelencia. \xA1Conoce m\xE1s sobre nuestra historia \xFAnica y s\xE9 parte de nuestro emocionante futuro!"
        },
        {
          name: "og:image",
          content: "/favicon.ico"
        },
        {
          name: "twitter:image",
          content: "/favicon.ico"
        },
        {
          name: "og:title",
          content: "Nuestra historia - Garnier BBDO"
        },
        {
          name: "twitter:title",
          content: "Nuestra historia - Garnier BBDO"
        },
        {
          name: "og:description",
          content: "Descubre la inspiradora historia detr\xE1s de Garnier. Desde nuestros humildes comienzos hasta convertirnos en l\xEDderes de la industria, hemos construido nuestro camino con pasi\xF3n, innovaci\xF3n y dedicaci\xF3n. Explora c\xF3mo hemos superado desaf\xEDos, hemos alcanzado \xE9xitos significativos y hemos forjado relaciones s\xF3lidas. \xDAnete a nosotros en este viaje, donde cada cap\xEDtulo cuenta una historia de crecimiento, creatividad y compromiso con la excelencia. \xA1Conoce m\xE1s sobre nuestra historia \xFAnica y s\xE9 parte de nuestro emocionante futuro!"
        },
        {
          name: "twitter:description",
          content: "Descubre la inspiradora historia detr\xE1s de Garnier. Desde nuestros humildes comienzos hasta convertirnos en l\xEDderes de la industria, hemos construido nuestro camino con pasi\xF3n, innovaci\xF3n y dedicaci\xF3n. Explora c\xF3mo hemos superado desaf\xEDos, hemos alcanzado \xE9xitos significativos y hemos forjado relaciones s\xF3lidas. \xDAnete a nosotros en este viaje, donde cada cap\xEDtulo cuenta una historia de crecimiento, creatividad y compromiso con la excelencia. \xA1Conoce m\xE1s sobre nuestra historia \xFAnica y s\xE9 parte de nuestro emocionante futuro!"
        }
      ]
    });
    const { data } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "about",
      () => $fetch(`/api/about`, {
        method: "GET",
        baseURL: "https://admin.garnierbbdo.com"
      })
    )), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "page desde-1921" }, _attrs))}><section><section class="image"><img${ssrRenderAttr("src", (_a = unref(data)) == null ? void 0 : _a.data.items.photo)}${ssrRenderAttr("alt", (_b = unref(data)) == null ? void 0 : _b.data.items.title)}${ssrRenderAttr("title", (_c = unref(data)) == null ? void 0 : _c.data.items.title)}></section><section class="content"><h1${ssrRenderAttr("title", (_d = unref(data)) == null ? void 0 : _d.data.items.title)}>${ssrInterpolate((_e = unref(data)) == null ? void 0 : _e.data.items.title)}</h1><div class="description">${(_f = unref(data)) == null ? void 0 : _f.data.items.description}</div></section></section></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/desde-1921/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-CJFVhzds.mjs.map
