const client_manifest = {
  "_index.!~{00e}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.b7Wr6F05.css",
    "src": "_index.!~{00e}~.js"
  },
  "_index.2iwjVWhi.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.b7Wr6F05.css"
    ],
    "file": "index.2iwjVWhi.js",
    "imports": [
      "_swiper-vue.Gi1GZpm4.js"
    ]
  },
  "index.b7Wr6F05.css": {
    "file": "index.b7Wr6F05.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_swiper-vue.!~{002}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "swiper-vue.jYBRVk-X.css",
    "src": "_swiper-vue.!~{002}~.js"
  },
  "_swiper-vue.Gi1GZpm4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "swiper-vue.jYBRVk-X.css"
    ],
    "file": "swiper-vue.Gi1GZpm4.js"
  },
  "swiper-vue.jYBRVk-X.css": {
    "file": "swiper-vue.jYBRVk-X.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_volcan_logo.DmZMiU15.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "assets": [
      "volcan_logo.iqfWTAW2.svg"
    ],
    "file": "volcan_logo.DmZMiU15.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "volcan_logo.iqfWTAW2.svg": {
    "file": "volcan_logo.iqfWTAW2.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "_vue.f36acd1f.KEesW_tm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vue.f36acd1f.KEesW_tm.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Gi1GZpm4.js"
    ]
  },
  "assets/fonts/din/din-bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "din-bold.3z1zPOcm.ttf",
    "src": "assets/fonts/din/din-bold.ttf"
  },
  "assets/fonts/din/din.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "din.QqJ2hcHX.ttf",
    "src": "assets/fonts/din/din.ttf"
  },
  "assets/fonts/gobold/gobold_regular.otf": {
    "resourceType": "font",
    "mimeType": "font/otf",
    "file": "gobold_regular._CYe74n7.otf",
    "src": "assets/fonts/gobold/gobold_regular.otf"
  },
  "assets/fonts/noway/noway-bold-webfont.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "noway-bold-webfont.cVPFjh_G.ttf",
    "src": "assets/fonts/noway/noway-bold-webfont.ttf"
  },
  "assets/fonts/noway/noway-regular-webfont.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "noway-regular-webfont.8-5P6w-O.ttf",
    "src": "assets/fonts/noway/noway-regular-webfont.ttf"
  },
  "assets/img/volcan_logo.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "volcan_logo.iqfWTAW2.svg",
    "src": "assets/img/volcan_logo.svg"
  },
  "node_modules/bootstrap-icons/font/fonts/bootstrap-icons.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "bootstrap-icons.TqycWyKO.woff",
    "src": "node_modules/bootstrap-icons/font/fonts/bootstrap-icons.woff"
  },
  "node_modules/bootstrap-icons/font/fonts/bootstrap-icons.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "bootstrap-icons.bb42NSi8.woff2",
    "src": "node_modules/bootstrap-icons/font/fonts/bootstrap-icons.woff2"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "assets": [
      "bootstrap-icons.bb42NSi8.woff2",
      "bootstrap-icons.TqycWyKO.woff"
    ],
    "css": [
      "entry.B0CYX1WF.css"
    ],
    "dynamicImports": [],
    "file": "entry.RSjM6ljS.js",
    "imports": [
      "_swiper-vue.Gi1GZpm4.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.B0CYX1WF.css": {
    "file": "entry.B0CYX1WF.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "bootstrap-icons.bb42NSi8.woff2": {
    "file": "bootstrap-icons.bb42NSi8.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "bootstrap-icons.TqycWyKO.woff": {
    "file": "bootstrap-icons.TqycWyKO.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "pages/clientes/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.pjKUr0Xw.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_vue.f36acd1f.KEesW_tm.js",
      "_swiper-vue.Gi1GZpm4.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/clientes/index.vue"
  },
  "pages/desde-1921/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.56bDybA9.js",
    "imports": [
      "_vue.f36acd1f.KEesW_tm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Gi1GZpm4.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/desde-1921/index.vue"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.lrAhc__J.js",
    "imports": [
      "_volcan_logo.DmZMiU15.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Gi1GZpm4.js",
      "_index.2iwjVWhi.js",
      "_vue.f36acd1f.KEesW_tm.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "pages/insaltable.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "insaltable.1MSDDteC.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Gi1GZpm4.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/insaltable.vue"
  },
  "pages/insaltable/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.klmcj3sI.js",
    "imports": [
      "_index.2iwjVWhi.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Gi1GZpm4.js",
      "_vue.f36acd1f.KEesW_tm.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/insaltable/[slug].vue"
  },
  "pages/insaltable/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.ALoe-dfZ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_vue.f36acd1f.KEesW_tm.js",
      "_swiper-vue.Gi1GZpm4.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/insaltable/index.vue"
  },
  "pages/oportunidades.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "oportunidades.1GvyhPYm.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Gi1GZpm4.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/oportunidades.vue"
  },
  "pages/oportunidades/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.Y_a1MCR5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Gi1GZpm4.js",
      "_volcan_logo.DmZMiU15.js",
      "_vue.f36acd1f.KEesW_tm.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/oportunidades/[slug].vue"
  },
  "pages/oportunidades/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.8IEmpX4A.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Gi1GZpm4.js",
      "_vue.f36acd1f.KEesW_tm.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/oportunidades/index.vue"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
