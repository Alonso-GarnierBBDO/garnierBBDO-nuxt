import"./entry.RSjM6ljS.js";const r=""+new URL("volcan_logo.iqfWTAW2.svg",import.meta.url).href;export{r as _};
